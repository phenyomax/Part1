﻿namespace Part1
{
    public class Step
    {
        public string Description { get; set; }
    }
}
